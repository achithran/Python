# Curly brackets for sets & dicts
s = {
    2,
    6,
    1,
    9,
    2,
    100,
    -50,
    2,
    20,
    -10,
    2,  # int
    "hello",  # str
    (6, 23),  # tuple
    4.56,  # float
    True,  # boolean
    2,
    2,
    2,
    # [7, 34, 2, 0],   # list cannot be put inside set
}

print(s)
