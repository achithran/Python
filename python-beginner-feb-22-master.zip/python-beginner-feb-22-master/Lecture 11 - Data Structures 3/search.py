s = {6, 5, 2, 8, 9, 1, 0, "hello", (2, 3)}

num = 50

if num in s:
    print("Found")
else:
    print("Not found")
