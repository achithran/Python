l = [2, 6, 3, 1]
t = (9, 5, 2, 1)

# s = set()
# s.update(l)

s = set(t)

print(s)
