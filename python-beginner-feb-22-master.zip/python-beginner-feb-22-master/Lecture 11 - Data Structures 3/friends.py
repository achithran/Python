# Make a list of unique tv shows compiling from all your friends' favourite tv shows


friend1 = ["How I Met Your Mother", "Breaking Bad", "The Wire"]

friend2 = ["Breaking Bad", "Westworld", "The Office"]

friend3 = ["Sopranos", "Game of Thrones", "Sherlock"]

friend4 = ["Friends", "Sherlock", "Daredevil"]


# A fifth friend comes along and produces his tv show list. He wants to check which of the shows you have in common with his list.
# friend5 = ["The Office", "Doctor Who", "Peaky Blinders"]
