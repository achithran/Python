s = {6, 5, 2, 8, 9, 1, 0, "hello", (2, 3)}


for x in s:
    print(x)

print("Length = ", len(s))
