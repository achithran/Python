s = "tenet"

rev = s[::-1]

if s == rev:
    print("Palindrome")
else:
    print("Not a palindrome")
