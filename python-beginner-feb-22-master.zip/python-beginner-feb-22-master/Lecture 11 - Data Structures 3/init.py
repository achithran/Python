s = set()  # empty set
l = list()
l2 = []
t = tuple()
t2 = ()

d2 = dict()
d = {}  # empty dict

print(s)
print(type(d))
