d = {"hello": "world", "some_list": [1, 2, 3, 4]}

print(d["some_list"][2])


d["hello"] = "everyone"
