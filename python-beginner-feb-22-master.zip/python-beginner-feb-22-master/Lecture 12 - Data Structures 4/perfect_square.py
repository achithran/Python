n = 100

sq = n ** (1 / 2)
x = int(sq)

if x**2 == n:
    print("Perfect square!")
else:
    print("Not a perfect square.")
