import math

print(math.e)


print(math.sqrt(50))
