# Stop the loop after 10 iterations

for i in range(100):
    if i == 10:
        break
    print(i, end=' ')
