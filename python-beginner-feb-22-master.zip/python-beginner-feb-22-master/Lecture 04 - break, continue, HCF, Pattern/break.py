# Stop the loop after 10 iterations

i = 0
while i <= 100:
    if i == 10:
        break
    print(i, end=' ')
    i += 1
