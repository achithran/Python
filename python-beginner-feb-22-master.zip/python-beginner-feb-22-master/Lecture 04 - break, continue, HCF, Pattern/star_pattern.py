n = 3

# will print n rows
for i in range(1, n + 1):
    # in each row, print n stars
    print("* " * n)
