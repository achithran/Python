# Print the sum of even numbers from 1 till 10


s = 0

for i in range(2, 11, 2):
    print(i)
    s = s + i # sum += i

print()
print(s)