r = range(1,20,3)

# [1,4,7,10,13,16,19]

print(list(r))

print(list(range(4,20,5)))

print(list(range(10)))

print(list(range(3,12)))