x = 10

# Default behaviour
# sep=' '
# end='\n'

print("Hello World", "Good day to everyone", "I love python", sep='.,', end=';')
print("I am a programmer", "I love to code", sep='[]')
print("Hello", "everyone")



# print("Hello \nto everyone")