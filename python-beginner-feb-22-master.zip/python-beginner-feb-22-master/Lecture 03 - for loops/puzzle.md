## Puzzle - Hourglass

An eccentric professor used a unique way to measure time for a test lasting 15 minutes.

He used just two hourglasses. One measured 7 minutes and the other 11 minutes.

During the whole time he turned the hourglasses only 3 times.

How did he measure the 15 minutes?