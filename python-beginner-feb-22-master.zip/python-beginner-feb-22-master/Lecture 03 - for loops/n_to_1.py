# Print N to 1

n = int(input())

for i in range(n, 0, -1):
    print(i)

    