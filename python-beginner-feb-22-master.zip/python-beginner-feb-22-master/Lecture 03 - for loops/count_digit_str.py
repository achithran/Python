n = int(input())
# n = 987

# Convert n to a str
s = str(n)
# s = str(987)
# s = "987"


# No of digits = Length of string 
print(len(s))