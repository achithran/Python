for i in range(10, 2, -1):
    print(i, end=' ')

    