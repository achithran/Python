for num in range(1,10,2):
    print(num, end='.')