a = [1,2,3,4,5]

b = list(a)

b.append(500)

print(a)
print(b)

print(id(a))
print(id(b))