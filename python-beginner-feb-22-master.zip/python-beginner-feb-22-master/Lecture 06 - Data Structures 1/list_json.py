import json

a = json.loads(input())
print(a)
print(type(a[0]))