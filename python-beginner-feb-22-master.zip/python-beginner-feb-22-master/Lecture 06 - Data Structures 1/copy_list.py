a = [1,2,3]
b = a

b[2] = 1000
b.append(50)

print(a)
print(b)

b = [4,5,6]

print(a)
print(b)