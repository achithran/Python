a = [10,20,30,40,50]

# Reverse the list without using inbuilt function
# You must change the given list
# Do not create a new list

