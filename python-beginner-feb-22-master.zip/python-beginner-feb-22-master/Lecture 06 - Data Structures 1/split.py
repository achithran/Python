s = "hello everyone how are you"

l = s.split()

print(l)