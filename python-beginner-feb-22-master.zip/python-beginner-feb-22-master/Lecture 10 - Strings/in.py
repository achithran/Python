s = "Python is awesome"

if "Python" in s:
    print("It is present")


book = "Harry Potter and the Half Blood Prince"

if "a;" in book:
    print("Yes")
else:
    print("No")
