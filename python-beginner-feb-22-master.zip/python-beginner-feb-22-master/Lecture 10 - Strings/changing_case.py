s = "Python is Awesome. Python is Amazing."


# s2 will get a copy of s but with all lowercase chars
s2 = s.lower()
print(s2)

# s remains unchanged
print(s)


s3 = s.upper()
print(s3)

print(s)

s4 = s.capitalize()
print(s4)
