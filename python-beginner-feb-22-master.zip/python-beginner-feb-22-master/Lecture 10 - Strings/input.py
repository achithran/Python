# 5 10 20 30 40 50

l = list(map(int, input().split()))


n = l[0]
l = l[1:]

print(n)
print(l)
