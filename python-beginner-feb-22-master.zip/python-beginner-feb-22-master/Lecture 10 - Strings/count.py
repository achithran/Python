book = "Harry Potter and the Half Blood Prince"


print(book.count("an"))
