s = "Python"
s2 = "Java"
s3 = "C++"


print(s + s2 + s3)
