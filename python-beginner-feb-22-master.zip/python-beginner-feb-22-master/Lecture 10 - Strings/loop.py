for c in "Python is amazing":
    print(c, end="_")
