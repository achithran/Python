s = "hello"


print(s * 10)
print(s + s + s + s)
