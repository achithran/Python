s = "Python is amazing. It is so amazing that everyone loves it."

# "Python is awesome"


new_string = s.replace("amazing", "awesome", 1)


print(new_string)
print(s)
