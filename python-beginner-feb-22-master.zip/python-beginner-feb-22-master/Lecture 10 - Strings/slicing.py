a = "152"

print(a[::-1])
