s = "Python is amazing"

l = list(s)

print(l)
