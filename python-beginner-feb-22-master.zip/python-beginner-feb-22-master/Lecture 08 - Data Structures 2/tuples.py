t = (2, 4, 8, -9, 1, 5.2, "Hello", (2, 3), [6, 21, 8])

print(t)
print(type(t))

print(t[0])
print(t[3])


t[-1].append(20)

print(t)
