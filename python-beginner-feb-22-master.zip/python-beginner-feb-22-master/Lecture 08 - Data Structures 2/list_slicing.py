a = [2, 7, 1, 9, 4, 6, 5, 2, 0, 2]

# print(a[2:5])
# print(a[6:])
# print(a[:6])


# print(a[::-1])
print(a[9::-1])
print(len(a))
