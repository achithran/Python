name = input()

print("Hello",name,5)