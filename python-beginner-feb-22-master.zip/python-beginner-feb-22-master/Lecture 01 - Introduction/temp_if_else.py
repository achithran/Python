temp = 0


if temp >= 30:
    print("Hot day")
    print("It is a very sunny day")
elif 15 <= temp < 30:
    print("Pleasant day")
    print("Beautiful sky today")
elif 5 <= temp < 15:
    print("Slightly cold")
else:
    print("Cold day")
