a = input()
# a = "10"
b = input()
# b = "15"
c = input()
# c = "50"

s = a + b + c
# s = "10" + "15" + "50".    -> "101550"


print(s)



