a = 10
b = 15
c = 50

print(a + b + c)

s = a + b + c

print(s)