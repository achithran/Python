s = "abc"
t = "def"

print(s + t)