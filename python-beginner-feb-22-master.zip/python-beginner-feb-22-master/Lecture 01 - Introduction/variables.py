a = 10
b = 10

print(a)
print(b)
print(id(a))
print(id(b))

a = 11

print(a)
print(b)
print(id(a))
print(id(b))
