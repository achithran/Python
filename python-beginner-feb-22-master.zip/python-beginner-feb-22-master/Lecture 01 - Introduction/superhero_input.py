spiderman = input()
ironman = input()
batman = input()


print("Spiderman is", spiderman)
print("Iron man is ", ironman)
print("Batman is", batman)


print(spiderman, ironman, batman)