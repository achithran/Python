name = input()

print(name)