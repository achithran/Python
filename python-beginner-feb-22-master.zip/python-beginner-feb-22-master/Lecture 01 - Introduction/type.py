a = 10
print(type(a))


a = "10"
print(type(a))