def hello():
	print("Hello")
	greet()


def greet():
	print("Good morning")
	hello()


greet()