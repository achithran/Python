def square(x):
    return x ** 2


sq = square
# Value of 5 squared + 7 squared

y = sq(5)
z = sq(7)

print(y + z)
print(sq(5) + sq(7))