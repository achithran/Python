a = [2,6,1,7]

b = list(map(lambda x:x*x, a))

print(b)