def superhero(name, age=25, villains=['Thanos', "Ultron"]):
    print("Superhero:", name)
    print("Age:", age)
    print("Villains:", villains)


superhero("Spiderman",20,['Electro','Venom'])
superhero("Iron Man", 30)
