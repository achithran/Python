import math


def areaOfCircle(r):
    """This function accepts radius as argument and returns the area of circle."""
    return math.pi * r * r


print(areaOfCircle(5))
