def superhero(name, age, villains):
    print("Superhero:", name)
    print("Age:", age)
    print("Villains:", villains)
    print()



superhero("Spiderman", 20, ['Electro','Venom'])