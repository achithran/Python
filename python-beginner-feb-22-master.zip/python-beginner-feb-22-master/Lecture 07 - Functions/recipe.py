def tea():
    print("Boil some water with tea leaves and sugar")
    print("Add some milk")
    print("Let it boil")
    print()


def coffee():
    print("Boil some milk with sugar")
    print("Put some coffee powder")
    print()

tea()
coffee()
tea()
tea()
coffee()