print("Hello world")

x = 2

print(x**2)


y = int(input())