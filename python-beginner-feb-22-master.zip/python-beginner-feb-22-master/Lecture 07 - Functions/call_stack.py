def hello():
    print("Hello, how are you?")

def greet():
    print("Good morning")
    hello()

def main():
    print("Start of program")
    greet()
    print("End of program")


main()
