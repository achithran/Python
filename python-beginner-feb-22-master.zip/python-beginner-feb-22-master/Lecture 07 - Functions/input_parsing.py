a = list(map(int, input().split()))


print(a)