def superhero(name, age=25, villains=['Thanos']):
    print("Superhero:", name)
    print("Age:", age)
    print("Villains:", villains)


superhero(villains=['Electro','Venom'], name="Spiderman")