# How many values can we return ?

def trinity():
    return "Superman", "Batman", "Wonder Woman"


clark, bruce, diana = trinity()

print(clark)
print(bruce)
print(diana)