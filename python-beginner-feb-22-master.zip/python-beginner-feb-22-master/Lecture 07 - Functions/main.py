def hello(name):
    print("Hello", name)

hello("Tarun Luthra")
hello("Peter Parker")
hello("Bruce Wayne")

hello(5)
hello(3.14)
hello(["Hello", "World"])