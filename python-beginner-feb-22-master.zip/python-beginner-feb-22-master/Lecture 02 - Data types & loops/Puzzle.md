## Jailer Puzzle

![](https://media.giphy.com/media/xUPGcFnu29iMys4Lkc/giphy.gif)

There is a circular jail with 100 cells numbered 1-100. Each cell has an inmate and the door is locked. One night the jailer got drunk and starts running around the jail in circles.
In his first round he opens each door.
In his second round, he visits every 2nd door (2,4,6,…100) and if the door is shut he opens it, if it is open he shuts it.
This continues for 100 rounds (i.e. 4,8,12,…. ; 5,10,15,… ; 6,12,18,24,….) and exhausted the jailor falls down. How many prisoners found their doors open after 100 rounds ?
