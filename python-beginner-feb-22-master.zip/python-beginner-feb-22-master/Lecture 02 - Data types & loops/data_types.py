a = 10

print(type(a))

b = 'Hello World'
print(type(b))

c = -3.4
print(type(c))

d = False
print(type(d))

e = None
print(type(e))