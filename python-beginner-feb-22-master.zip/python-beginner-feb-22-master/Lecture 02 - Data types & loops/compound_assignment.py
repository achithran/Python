# compound assignment


i = 5
# i = i + 10

i += 10

print(i)


a = 2
a = a * 7
a *= 7

b = 10
b -= 2 # b = b -2 

b /= 4 # b = b /4
b //= 3 # b = b // 3