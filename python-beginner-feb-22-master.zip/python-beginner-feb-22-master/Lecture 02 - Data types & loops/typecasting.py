# Typecasting - changing the type of data


s = "123"
print(type(s))

# str -> int
a = int(s)
print(a, type(a))


# int -> str
b = 38974589
c = str(b)

print(c, type(c))

# int -> float
a = float(5)
print(a, type(a))

#  float -> int
b = int(3.45)
print(b)

# str -> float
c = float("7.345")
print(c, type(c))

# float -> str
d = str(-234.2352345)
print(d, type(d))


# s = 'gaurav'
# a = int(s)

# print(a)