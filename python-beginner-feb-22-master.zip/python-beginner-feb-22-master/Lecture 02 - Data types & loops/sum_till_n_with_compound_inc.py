# initialisation
i = 1
sum = 0

n = int(input())

# condition
while i <= n:
    sum = sum + i   # work
    # i = i + 1 # update
    i += 1


print(sum)