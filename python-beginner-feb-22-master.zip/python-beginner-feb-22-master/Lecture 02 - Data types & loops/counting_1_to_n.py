# print numbers from 1 to 10

# initialisation
i = 1

n = int(input())

while i <= n:
    print(i) # work
    i = i + 1 #increment  (update part)



print("After the loop")