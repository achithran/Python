def isvowel(C):
    ans = None
    
    if C == 'a' or C == 'e' or C == 'i' or C == 'o' or C == 'u':
        ans = 1
    else:
        ans = 0

    
    return ans