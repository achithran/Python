# Operators
a = 5
b = 3

print(a + b) # sum operator

# subtraction
print(a - b)

# multiplication
print(a * b)


# division
print(a / b)
print(a // b)

# modulo operator - remainder
print(a % b)

# exponent operator
print(a ** b)
print(2 ** 4)

