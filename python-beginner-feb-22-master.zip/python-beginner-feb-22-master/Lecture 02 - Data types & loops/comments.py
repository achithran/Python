a = 10
# this is a comment
# b = "Hello World"

