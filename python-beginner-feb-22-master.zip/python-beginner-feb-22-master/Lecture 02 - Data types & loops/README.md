## Installing Python, Jupyter, Pycharm, VSCode

https://github.com/tarunluthra123/docs/blob/master/Installing%20Python.md

## Comments

Comments are statements that are written inside the code but they are ignored by the interpreter. These are written to make the code understandable and readable.

## Data Types

- Integers - int
- Floating point numbers - float
- Strings - str
- Boolean Type - bool
- NoneType
