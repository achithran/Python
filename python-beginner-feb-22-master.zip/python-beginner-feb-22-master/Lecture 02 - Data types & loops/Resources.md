## Resources

- Learning Basics - https://www.scaler.com/topics/hubs/python/
- Understanding the WTFs- https://github.com/satwikkansal/wtfpython
- List of awesome Python frameworks, libraries, software and resources - https://github.com/vinta/awesome-python
