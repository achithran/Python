def main():
    a = int(input())
    
    if a % 2 == 0:
        print(0)
    else:
        print(1)
        
    
    return 0

if __name__ == '__main__':
    main()